<?php 
	include('../functions.php');
  include('../includes/header.php');
	if (!isAdmin()) {
		$_SESSION['msg'] = "You must log in first";
		header('location: ../login.php');
	}
?>

<div class="d-flex" id="wrapper">

    <!-- Sidebar -->
<div class="bg-light border-right" id="sidebar-wrapper">
  <div class="sidebar-heading"> </div>
    <div class="list-group list-group-flush">
    <a href="http://localhost/phpmyadmin" target="_blank" class="list-group-item list-group-item-action bg-light">PHP MyAdmin</a>
    <a href="#" class="list-group-item list-group-item-action bg-light"> </a>
    <a href="http://localhost/phpmyadmin/server_status_monitor.php" target="_blank" class="list-group-item list-group-item-action bg-light">Server Status</a>

    <a href="http://localhost/phpmyadmin/server_sql.php" target="_blank" class="list-group-item list-group-item-action bg-light">Run SQL query</a>
    <a href="#" class="list-group-item list-group-item-action bg-light"> </a>
    <a href="#" class="list-group-item list-group-item-action bg-light"> </a>
    <a href="#" class="list-group-item list-group-item-action bg-light"> </a>
    <a href="home.php?logout='1'" class="list-group-item list-group-item-action bg-light">Logout</a>
    </div>
</div>

<!-- /#sidebar-wrapper -->


<!-- Menu Toggle Script -->

  <div id="page-content-wrapper">
     
  <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
    <button class="btn btn-outline-success" id="menu-toggle">
    <span class="navbar-toggler-icon"></span>
    </button>
  </nav>  


  <div class="container-fluid">
		<!-- notification message -->
		<?php if (isset($_SESSION['success'])) : ?>
			<div class="error success" >
				<h4>
					<?php 
						echo $_SESSION['success']; 
						unset($_SESSION['success']);
					?>
				</h4>
			</div>
		<?php endif ?>
		<!-- logged in user information -->  	
    <h4 class="mt-4">[Administrator] Homepage </h4> 
	<div>
		<?php  if (isset($_SESSION['user'])) : ?>
		<strong><?php echo $_SESSION['user']['username']; ?></strong>
		<h4>(<?php echo ucfirst($_SESSION['user']['user_type']); ?>)</h4>
			<?php endif ?>
	</div>
    <p>Let's hit 4.0</p>

  	</div>
  </div><!-----id="page-content-wrapper"---->
</div><!---id="wrapper"------->


<script>
  $("#menu-toggle").click(function(e) {
    e.preventDefault();
  $("#wrapper").toggleClass("toggled");
  });
</script>

<?php
	include('../includes/footer.php');
?>