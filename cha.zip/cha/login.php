<?php 
	include('functions.php');
	include('includes/header.php');
?>
<div style="margin:0 auto;width:75%;text-align:left" >	
	<div class="header">
		<h2>Login</h2>
	</div>
	
	<form method="post" action="login.php"  >

		<?php echo display_error(); ?>

		<div class="input-group">
			<label>Username</label>	
			<input type="text" name="username" >
		</div>
		<div class="input-group">
			<label>Password</label>
			<input type="password" name="password">
		</div>
		<div class="input-group">
			<button type="submit" class="btn btn-primary" name="login_btn">Login</button>
			<a href="forgot.php" class="btn btn-warning" role="button">Forgot password</a>
		</div>	
		<p><br>
			Not yet a member? <a href="register.php">Sign up</a>
		</p>

		<?php
		function loginForm() {
    	echo'
			<div id="loginform">
			<form action="." method="post">
			<p>Please enter your name to continue:</p>
			<label for="name">Name:</label>
			<input type="text" name="name" id="name" autofocus />
			<input type="submit" name="enter" id="enter" value="Enter" />
			</form>
			</div>
		';
		}
		?>

	</form>
</div>

<?php include('includes/footer.php'); ?>