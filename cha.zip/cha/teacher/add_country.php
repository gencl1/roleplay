<?php 
	include('../functions.php'); 
	include('../includes/header.php');
    // If form submitted, insert values into the database.
    // Anti SQL injection scripy
    if (isset($_REQUEST['name'])){
		$name = stripslashes($_REQUEST['name']); // removes backslashes
		$name = mysqli_real_escape_string($db,$name); //escapes special characters in a string
        $query = "INSERT into `country` (name) VALUES ('$name')";
        $result = mysqli_query($db,$query);
        if($result){
            echo "<div class='form'><h3>Country was added successfully.</h3></div>";
        }
    }{
    	echo "";
    }
?>
<div class="form">
	<h1>Add Country</h1>
<form name="add" action="" method="post">
	<input type="text" name="name" placeholder="Name" required />

    <input type="submit" name="submit" class="btn btn-primary" value="Save" />
    <a href="javascript:window.close()" class="btn btn-warning" role="button">Back</a>          
</form>
</div>
<?php 	include('../includes/footer.php'); ?>