<?php 
	include('../functions.php');
  include('../includes/header.php');
	if (!isTeacher()) {
		$_SESSION['msg'] = "You must log in first";
		header('location: ../login.php');
	}
?>

<div class="d-flex" id="wrapper">

    <!-- Sidebar -->
<div class="bg-light border-right" id="sidebar-wrapper">
  <div class="sidebar-heading"> </div>
    <div class="list-group list-group-flush">
    <a href="#" class="list-group-item list-group-item-action bg-light">Dashboard</a>
    <a href="#" class="list-group-item list-group-item-action bg-light"> </a>
    <a href="tada.php" target="_blank" class="list-group-item list-group-item-action bg-light">Add Score</a>
    <a href="tada.php" target="_blank" class="list-group-item list-group-item-action bg-light">Add Attendance</a>
    <a href="tada.php" target="_blank" class="list-group-item list-group-item-action bg-light">Add Subject</a>
    <a href="tada.php" target="_blank" class="list-group-item list-group-item-action bg-light">Add Grade Category</a>
     
    <a href="#" class="list-group-item list-group-item-action bg-light"> </a>
    <a href="container-fluid" onclick="window.print();return false;" class="list-group-item list-group-item-action bg-light"> Print</a>
    <a href="#" class="list-group-item list-group-item-action bg-light"> </a>
    <a href="home.php?logout='1'" class="list-group-item list-group-item-action bg-light">Logout</a>
    <a href="#" class="list-group-item list-group-item-action bg-light"></a>
    <a href="#" class="list-group-item list-group-item-action bg-light"></a>
    <a href="#" class="list-group-item list-group-item-action bg-light"></a>
    </div>
</div>
    <!-- /#sidebar-wrapper -->


<!-- Menu Toggle Script -->

  <div id="page-content-wrapper">
     
  <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
    <button class="btn btn-outline-success" id="menu-toggle">
    <span class="navbar-toggler-icon"></span>
    </button>
  </nav>  


  <div class="container-fluid">
		<!-- notification message -->
		<?php if (isset($_SESSION['success'])) : ?>
			<div class="error success" >
				<h4>
					<?php 
						echo $_SESSION['success']; 
						unset($_SESSION['success']);
					?>
				</h4>
			</div>
		<?php endif ?>
		<!-- logged in user information -->  	
    <h4 class="mt-4">[Teacher] Homepage </h4> 
    
    <div name="myframe">
      <iframe width="800" height="600" src="https://app.powerbi.com/view?r=eyJrIjoiZWY1NzQ4MjYtZTYwNi00N2Y0LWJiOWEtZjU2ZDU0NzQ5Mjg4IiwidCI6ImFlYjc0NWU2LTgxNjYtNGY4Zi05MjMzLTE3OWU4MTA5YzQ5ZSIsImMiOjEwfQ%3D%3D" frameborder="0" allowFullScreen="true"></iframe>
    </div>
	<div>
		<?php  if (isset($_SESSION['user'])) : ?>
		<strong><?php echo $_SESSION['user']['username']; ?></strong>
		<h4>(<?php echo ucfirst($_SESSION['user']['user_type']); ?>)</h4>
			<?php endif ?>
	</div>
		<!--iframe name="myframe" frameboarder="0"></iframe--->
  	</div>
  </div><!-----id="page-content-wrapper"---->
</div><!---id="wrapper"------->


<script>
  $("#menu-toggle").click(function(e) {
    e.preventDefault();
  $("#wrapper").toggleClass("toggled");
  });
</script>

<!-- Printer-------->
<script>
function myFunction() {
  window.print();
}
</script>

<?php
	include('../includes/footer.php');
?>