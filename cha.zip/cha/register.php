<?php 
	include('functions.php');
	include('includes/header.php');
?>

<body>
	<div class="header" style="margin:0 auto;width:75%;text-align:left">
		<h2>Register</h2>
	</div>
	
	<form method="post" action="register.php" style="margin:0 auto;width:75%;text-align:left">

		<?php echo display_error(); ?>

		<div class="input-group">
			<label>Firstname</label>
			<input type="text" name="firstname" value="<?php echo $firstname; ?>">
		</div>
		<div class="input-group">
			<label>Lastname</label>
			<input type="text" name="lastname" value="<?php echo $lastname; ?>">
		</div>
		<!--div class="input-group">
			<label>Address</label>
			<input type="text" name="address" value="<?php echo $address; ?>">
		</div>
		<div class="input-group">
			<label>Phone</label>
			<input type="number" name="phone" value="<?php echo $phone; ?>">
		</div>
		<div class="input-group">
			<label>Email</label>
			<input type="email" name="email" value="<?php echo $email; ?>"--->
		</div>
		<div class="input-group">
			<label>Username</label>
			<input type="text" name="username" value="<?php echo $username; ?>">
		</div>		
		<div class="input-group">
			<label>Password</label>
			<input type="password" name="password_1">
		</div>
		<div class="input-group">
			<label>Confirm password</label>
			<input type="password" name="password_2">
		</div>
		<div class="input-group">
			<button type="submit" class="btn btn-primary" name="register_btn">Register</button>
		</div>
		<p>
			Already a member? <a href="login.php">Sign in</a>
		</p>
	</form>
</body>
</html>

<?php include('includes/footer.php'); ?>