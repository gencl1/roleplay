<?php include('includes/header.php')  ?>

<div class="d-flex" id="wrapper">

<?php include('includes/sidebar.php')  ?>
  <!-- Page Content -->
  <div id="page-content-wrapper">
      
  <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
    <button class="btn btn-outline-success" id="menu-toggle">
    <span class="navbar-toggler-icon"></span>
    </button>
  </nav>  

  <div class="container-fluid">
    <h1 class="mt-4">Dashboard</h1>
    <p>Let's hit 4.0</p>
  </div>
  </div>
    <!-- /#page-content-wrapper -->
</div>
  <!-- /#wrapper -->

<!-- Menu Toggle Script -->
<script>
  $("#menu-toggle").click(function(e) {
    e.preventDefault();
  $("#wrapper").toggleClass("toggled");
  });
</script>

<?php include('includes/footer.php')  ?>