<?php ?>
<html>
 <head>
  <title>MaTech</title>
   <link rel="shortcut icon" type="image/jpg" href="img/profile.jpg">
   <link rel="stylesheet" href="css/main.css">
   <link rel="stylesheet" href="css/bootstrap.min.css">

  <!-- Bootstrap core JavaScript -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>

 </head>

  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
<body>
  <nav id="navbar-site" class="navbar navbar-dark bg-dark navbar-expand-sm">
    <a class="navbar-brand" href="">MaTech<span class="text-success"> Systems</span></a>
  </nav>
