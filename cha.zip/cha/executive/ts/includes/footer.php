</body>
<nav class="navbar fixed-bottom navbar-dark bg-dark">
  <a class="navbar-brand" href="">All rights reserved for GMIT181</a>
</nav>