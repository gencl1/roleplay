<?php 
	include('../functions.php');
	include('../includes/header.php');
    // Anti SQL injection scripy
    if (isset($_REQUEST['name'])){

		$name = stripslashes($_REQUEST['name']); // removes backslashes
		$name = mysqli_real_escape_string($db,$name); //escapes special characters in a string

		$address = stripslashes($_REQUEST['address']);
		$address = mysqli_real_escape_string($db,$address);

		$creditlimit = stripslashes($_REQUEST['creditlimit']);
		$creditlimit = mysqli_real_escape_string($db,$creditlimit);

		$fname = stripslashes($_REQUEST['fname']);
		$fname = mysqli_real_escape_string($db,$fname);

		$lname = stripslashes($_REQUEST['lname']);
		$lname = mysqli_real_escape_string($db,$lname);

		$primaryhome = stripslashes($_REQUEST['primaryhome']);
		$primaryhome= mysqli_real_escape_string($db,$primaryhome);

		$email = stripslashes($_REQUEST['email']);
		$email = mysqli_real_escape_string($db,$email);

		$phone = stripslashes($_REQUEST['phone']);
		$phone = mysqli_real_escape_string($db,$phone);

		$rec_date = date("Y-m-d H:i:s");

        $query = "INSERT into `customer` ( name, address, creditlimit, fname, lname, primaryhome, email, phone) VALUES ( '$name','$address','$creditlimit', '$fname', '$lname', '$primaryhome','$email','$phone')";



        $result = mysqli_query($con,$query);
        if($result){
            echo "<div class='form'><h3>Customer was added successfully.</h3></div>";
        }
    }else{}
?>
<div class="form">
	<h1>Add Customer</h1>
<form name="add" action="" method="post">
	<input type="text" name="name" placeholder="Name" required /><br>
	<input type="text" name="address" placeholder="Address" required /><br>
	<input type="number" name="creditlimit" placeholder="CreditLimit" required /><br>
	<input type="text" name="fname" placeholder="Firstname" required /><br>
	<input type="text" name="lname" placeholder="Lastname" required /><br>
	<input type="text" name="primaryhome" placeholder="PrimaryHome" required /><br>
	<input type="email" name="email" placeholder="Email" required /><br>
	<input type="text" name="phone" placeholder="Phone" required /><br>

	<input type="submit" name="submit" class="btn btn-primary" value="Save" />
	<a href="javascript:window.close()" class="btn btn-warning" role="button">Back</a>		
</form>
	<br />
	

</div>
<?php  ?>
</body>
</html>
