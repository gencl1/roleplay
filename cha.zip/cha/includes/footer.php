<?php ?>
</body>
<nav class="navbar fixed-bottom navbar-dark bg-dark">
  <a class="navbar-brand" href="">github.com/mfrigillana</a>
</nav>
</html>