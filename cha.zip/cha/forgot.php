<?php include('functions.php') ?>
<?php include('includes/header.php') ?>

<!DOCTYPE html>
<html>
<head>
	<title>Recover</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="header">
		<h2>Forgot password?</h2>
	</div>
	
	<form method="post" action="forgot.php">

		<?php echo display_error(); ?>

		<div class="input-group">
			<label>Email or username</label>
			<input type="text" name="username" value="<?php echo $username; ?>">
		</div>
		<div class="input-group">
			<button type="submit" class="btn btn-primary" name="forgot_btn">Recover</button>
		</div>
		<p>
			Already a member? <a href="login.php">Sign in</a>
		</p>
	</form>
</body>
</html>

<?<?php include('includes/footer.php'); ?>